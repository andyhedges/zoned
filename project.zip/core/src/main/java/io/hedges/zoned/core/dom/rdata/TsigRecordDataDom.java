package io.hedges.zoned.core.dom.rdata;

import io.hedges.zoned.core.dom.RDataDom;

public class TsigRecordDataDom implements RDataDom {
}
